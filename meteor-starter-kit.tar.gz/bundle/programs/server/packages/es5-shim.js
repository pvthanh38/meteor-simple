(function () {



/* Exports */
Package._define("es5-shim");

})();
