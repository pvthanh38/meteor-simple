var require = meteorInstall({"lib":{"routes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// lib/routes.js                                                               //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);

if (Meteor.isClient) {}

FlowRouter.triggers.enter([function (context, redirect) {
  if (!Meteor.userId()) {
    FlowRouter.go('/');
  }
}]);
FlowRouter.route('/', {
  name: "home",

  action() {
    BlazeLayout.render('HomeLayout', {
      content: 'Content'
    });
  }

});
FlowRouter.route('/recipe-book', {
  name: "recipe-book",

  action() {
    BlazeLayout.render('MainLayout', {
      main: 'Content'
    });
  }

});
FlowRouter.route('/book', {
  name: "book",

  action() {
    BlazeLayout.render('HomeLayout', {
      content: 'insertBookForm'
    });
  }

});
FlowRouter.route('/book/:id', {
  name: "book",

  action(params, queryParams) {
    BlazeLayout.render('HomeLayout', {
      content: 'BookDetail'
    });
  }

});
FlowRouter.route('/blog/:postId', {
  action: function (params, queryParams) {
    console.log("Yeah! We are on the post:", params.postId);
  }
});
/////////////////////////////////////////////////////////////////////////////////

}},"imports":{"api":{"schema.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// imports/api/schema.js                                                       //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.export({
  typeDefs: () => typeDefs,
  resolvers: () => resolvers
});
let Random;
module.watch(require("meteor/random"), {
  Random(v) {
    Random = v;
  }

}, 0);
const laptops = [{
  name: "MacBookPro",
  ram: "16GB",
  cpu: "i7 7700HQ",
  price: 9000000
}, {
  name: "Lenovo",
  ram: "16GB",
  cpu: "i5 7200U",
  price: 8000000
}, {
  name: "HP",
  ram: "32GB",
  cpu: "i7 7700HQ",
  price: 5000000
}];
const typeDefs = [`
 
type Laptop { name: String, cpu: String, ram: String, price: Float,}

type Email {
  address: String
  verified: Boolean
}

type User {
  emails: [Email]
  randomString: String
  _id: String
}

type Query {
  user: User,
  laptops: [Laptop]
}
`];
const resolvers = {
  Query: {
    user(root, args, context) {
      /*
       * We access to the current user here thanks to the context. The current
       * user is added to the context thanks to the `meteor/apollo` package.
       */
      return context.user;
    },

    laptops: () => laptops
  },
  User: {
    emails: ({
      emails
    }) => emails,
    randomString: () => Random.id()
  }
};
/////////////////////////////////////////////////////////////////////////////////

}}},"collections":{"Books.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// collections/Books.js                                                        //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
//SimpleSchema.extendOptions(['autoform']);
Books = new Meteor.Collection("books");
Books.allow({
  insert: function (userId, doc) {
    // write some logic to allow the insert 
    return !!userId;
  },
  update: function () {
    return true;
  },
  remove: function () {
    return true;
  }
});
Ingredient = new SimpleSchema({
  name: {
    type: String
  },
  amouny: {
    type: String
  }
});
BookSchema = new SimpleSchema({
  title: {
    type: String,
    label: "Title",
    max: 200,
    required: true
  },
  registered: {
    type: Boolean
  },
  ingredients: Array,
  "ingredients.$": Ingredient,
  author: {
    type: String,
    label: "Author",
    autoValue: function () {
      return this.userId;
    }
  },
  copies: {
    type: Number,
    label: "Number of copies",
    min: 0
  },
  lastCheckedOut: {
    type: Date,
    label: "Last date this book was checked out",
    optional: true
  },
  summary: {
    type: String,
    label: "Brief summary",
    optional: true,
    max: 1000
  }
});
Meteor.methods({
  toggleMenuItem: function (id, currentState) {
    Books.update({
      _id: id
    }, {
      $set: {
        registered: true
      }
    });
    console.log('update');
  }
});
Books.attachSchema(BookSchema); //Books.schema.validate(list);
/////////////////////////////////////////////////////////////////////////////////

},"Recipes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// collections/Recipes.js                                                      //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
SimpleSchema.extendOptions(['autoform']);
lineVar = new Meteor.Collection("linenvd3");
lineVar.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  },
  remove: function () {
    return true;
  }
});
Recipes = new Meteor.Collection('recipes');
Recipes.allow({
  insert: function (userId, doc) {
    return !!userId;
  },
  update: function () {
    return true;
  },
  remove: function () {
    return true;
  }
});
RecipeSchema = new SimpleSchema({
  name: {
    type: String,
    label: "Name"
  },
  desc: {
    type: String,
    label: "Description"
  },
  author: {
    type: String,
    label: "Author",
    autoValue: function () {
      return this.userId;
    }
  },
  createdAt: {
    type: Date,
    label: "Created At",
    autoValue: function () {
      return new Date();
    }
  }
});
Recipes.attachSchema(RecipeSchema);
/////////////////////////////////////////////////////////////////////////////////

}},"server":{"publish.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// server/publish.js                                                           //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

if (Meteor.isServer) {
  // This code only runs on the server
  Meteor.publish('recipes', function () {
    console.log('Published');
    return Recipes.find({
      author: this.userId
    });
  });
  Meteor.publish('books', function () {
    console.log('Published');
    return Books.find({});
  });
  Meteor.publish('singlebooks', function (id) {
    console.log('Published');
    check(id, String);
    return Books.find({
      '_id': id
    });
  });
} else {
  console.log("Not server");
}
/////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// server/server.js                                                            //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let createApolloServer;
module.watch(require("meteor/apollo"), {
  createApolloServer(v) {
    createApolloServer = v;
  }

}, 1);
let makeExecutableSchema;
module.watch(require("graphql-tools"), {
  makeExecutableSchema(v) {
    makeExecutableSchema = v;
  }

}, 2);
let typeDefs, resolvers;
module.watch(require("/imports/api/schema"), {
  typeDefs(v) {
    typeDefs = v;
  },

  resolvers(v) {
    resolvers = v;
  }

}, 3);
const schema = makeExecutableSchema({
  typeDefs,
  resolvers
});
createApolloServer({
  schema
});
Meteor.startup(() => {
  //Todos.insert({_id: 'my-todo'});
  //// So this line will return something
  //const todo = Todos.findOne({_id: 'my-todo'});
  // Look ma, no callbacks!
  //console.log(todo);
  //Recipes = new Mongo.Collection('recipes');
  //Books = new Mongo.Collection("books");
  if (Meteor.isServer) {}
  /*Meteor.publish("books", function () {
  //console.log(Books.find());
  	return Books.find();
  });
  Meteor.publish('singlebooks', function(id){
  	console.log('Published');
  	check(id, String);
  	return Books.find({'_id':id});
  });
  Meteor.methods({
  	toggleMenuItem: function(id, currentState){
  		Books.update({_id : id}, {
  			$set: {
  				registered: false
  			}
  		});
  		console.log('update');
  	}
  });*/
  //setupApi(); // instantiate our new Express app

});
/////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("/lib/routes.js");
require("/collections/Books.js");
require("/collections/Recipes.js");
require("/server/publish.js");
require("/server/server.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL3JvdXRlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2NoZW1hLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9Cb29rcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvUmVjaXBlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2guanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9zZXJ2ZXIuanMiXSwibmFtZXMiOlsiTW9uZ28iLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiTWV0ZW9yIiwiaXNDbGllbnQiLCJGbG93Um91dGVyIiwidHJpZ2dlcnMiLCJlbnRlciIsImNvbnRleHQiLCJyZWRpcmVjdCIsInVzZXJJZCIsImdvIiwicm91dGUiLCJuYW1lIiwiYWN0aW9uIiwiQmxhemVMYXlvdXQiLCJyZW5kZXIiLCJjb250ZW50IiwibWFpbiIsInBhcmFtcyIsInF1ZXJ5UGFyYW1zIiwiY29uc29sZSIsImxvZyIsInBvc3RJZCIsImV4cG9ydCIsInR5cGVEZWZzIiwicmVzb2x2ZXJzIiwiUmFuZG9tIiwibGFwdG9wcyIsInJhbSIsImNwdSIsInByaWNlIiwiUXVlcnkiLCJ1c2VyIiwicm9vdCIsImFyZ3MiLCJVc2VyIiwiZW1haWxzIiwicmFuZG9tU3RyaW5nIiwiaWQiLCJTaW1wbGVTY2hlbWEiLCJkZWZhdWx0IiwiQm9va3MiLCJDb2xsZWN0aW9uIiwiYWxsb3ciLCJpbnNlcnQiLCJkb2MiLCJ1cGRhdGUiLCJyZW1vdmUiLCJJbmdyZWRpZW50IiwidHlwZSIsIlN0cmluZyIsImFtb3VueSIsIkJvb2tTY2hlbWEiLCJ0aXRsZSIsImxhYmVsIiwibWF4IiwicmVxdWlyZWQiLCJyZWdpc3RlcmVkIiwiQm9vbGVhbiIsImluZ3JlZGllbnRzIiwiQXJyYXkiLCJhdXRob3IiLCJhdXRvVmFsdWUiLCJjb3BpZXMiLCJOdW1iZXIiLCJtaW4iLCJsYXN0Q2hlY2tlZE91dCIsIkRhdGUiLCJvcHRpb25hbCIsInN1bW1hcnkiLCJtZXRob2RzIiwidG9nZ2xlTWVudUl0ZW0iLCJjdXJyZW50U3RhdGUiLCJfaWQiLCIkc2V0IiwiYXR0YWNoU2NoZW1hIiwiZXh0ZW5kT3B0aW9ucyIsImxpbmVWYXIiLCJSZWNpcGVzIiwiUmVjaXBlU2NoZW1hIiwiZGVzYyIsImNyZWF0ZWRBdCIsImlzU2VydmVyIiwicHVibGlzaCIsImZpbmQiLCJjaGVjayIsImNyZWF0ZUFwb2xsb1NlcnZlciIsIm1ha2VFeGVjdXRhYmxlU2NoZW1hIiwic2NoZW1hIiwic3RhcnR1cCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxLQUFKO0FBQVVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0gsUUFBTUksQ0FBTixFQUFRO0FBQUNKLFlBQU1JLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7O0FBQ1YsSUFBR0MsT0FBT0MsUUFBVixFQUFtQixDQUdsQjs7QUFDREMsV0FBV0MsUUFBWCxDQUFvQkMsS0FBcEIsQ0FBMEIsQ0FBQyxVQUFTQyxPQUFULEVBQWtCQyxRQUFsQixFQUEyQjtBQUNyRCxNQUFHLENBQUNOLE9BQU9PLE1BQVAsRUFBSixFQUFvQjtBQUNuQkwsZUFBV00sRUFBWCxDQUFjLEdBQWQ7QUFDQTtBQUNELENBSnlCLENBQTFCO0FBS0FOLFdBQVdPLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0I7QUFDckJDLFFBQU0sTUFEZTs7QUFFckJDLFdBQVM7QUFDUkMsZ0JBQVlDLE1BQVosQ0FBbUIsWUFBbkIsRUFBaUM7QUFBQ0MsZUFBUztBQUFWLEtBQWpDO0FBQ0E7O0FBSm9CLENBQXRCO0FBTUFaLFdBQVdPLEtBQVgsQ0FBaUIsY0FBakIsRUFBaUM7QUFDaENDLFFBQU0sYUFEMEI7O0FBRWhDQyxXQUFTO0FBQ1JDLGdCQUFZQyxNQUFaLENBQW1CLFlBQW5CLEVBQWlDO0FBQUNFLFlBQU07QUFBUCxLQUFqQztBQUNBOztBQUorQixDQUFqQztBQU1BYixXQUFXTyxLQUFYLENBQWlCLE9BQWpCLEVBQTBCO0FBQ3pCQyxRQUFNLE1BRG1COztBQUV6QkMsV0FBUztBQUNSQyxnQkFBWUMsTUFBWixDQUFtQixZQUFuQixFQUFpQztBQUFDQyxlQUFTO0FBQVYsS0FBakM7QUFDQTs7QUFKd0IsQ0FBMUI7QUFPQVosV0FBV08sS0FBWCxDQUFpQixXQUFqQixFQUE4QjtBQUM3QkMsUUFBTSxNQUR1Qjs7QUFFN0JDLFNBQU9LLE1BQVAsRUFBZUMsV0FBZixFQUE0QjtBQUMzQkwsZ0JBQVlDLE1BQVosQ0FBbUIsWUFBbkIsRUFBaUM7QUFBQ0MsZUFBUztBQUFWLEtBQWpDO0FBQ0E7O0FBSjRCLENBQTlCO0FBT0FaLFdBQVdPLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0M7QUFDakNFLFVBQVEsVUFBU0ssTUFBVCxFQUFpQkMsV0FBakIsRUFBOEI7QUFDckNDLFlBQVFDLEdBQVIsQ0FBWSwyQkFBWixFQUF5Q0gsT0FBT0ksTUFBaEQ7QUFDQTtBQUhnQyxDQUFsQyxFOzs7Ozs7Ozs7OztBQ3BDQXhCLE9BQU95QixNQUFQLENBQWM7QUFBQ0MsWUFBUyxNQUFJQSxRQUFkO0FBQXVCQyxhQUFVLE1BQUlBO0FBQXJDLENBQWQ7QUFBK0QsSUFBSUMsTUFBSjtBQUFXNUIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDMEIsU0FBT3pCLENBQVAsRUFBUztBQUFDeUIsYUFBT3pCLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFFMUUsTUFBTTBCLFVBQVUsQ0FDZDtBQUFFZixRQUFNLFlBQVI7QUFBcUJnQixPQUFLLE1BQTFCO0FBQWlDQyxPQUFLLFdBQXRDO0FBQWtEQyxTQUFNO0FBQXhELENBRGMsRUFFZDtBQUFDbEIsUUFBTSxRQUFQO0FBQWdCZ0IsT0FBSyxNQUFyQjtBQUE0QkMsT0FBSyxVQUFqQztBQUE0Q0MsU0FBTTtBQUFsRCxDQUZjLEVBR2Q7QUFBQ2xCLFFBQU0sSUFBUDtBQUFZZ0IsT0FBSyxNQUFqQjtBQUF3QkMsT0FBSyxXQUE3QjtBQUF5Q0MsU0FBTTtBQUEvQyxDQUhjLENBQWhCO0FBTU8sTUFBTU4sV0FBVyxDQUN2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQUR1QixDQUFqQjtBQXVCQSxNQUFNQyxZQUFZO0FBQ3hCTSxTQUFPO0FBQ05DLFNBQUtDLElBQUwsRUFBV0MsSUFBWCxFQUFpQjNCLE9BQWpCLEVBQTBCO0FBQ3hCOzs7O0FBSUEsYUFBT0EsUUFBUXlCLElBQWY7QUFDRCxLQVBLOztBQVFOTCxhQUFTLE1BQU1BO0FBUlQsR0FEaUI7QUFXeEJRLFFBQU07QUFDTEMsWUFBUSxDQUFDO0FBQUVBO0FBQUYsS0FBRCxLQUFnQkEsTUFEbkI7QUFFTEMsa0JBQWMsTUFBTVgsT0FBT1ksRUFBUDtBQUZmO0FBWGtCLENBQWxCLEM7Ozs7Ozs7Ozs7O0FDL0JQLElBQUl6QyxLQUFKO0FBQVVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0gsUUFBTUksQ0FBTixFQUFRO0FBQUNKLFlBQU1JLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXNDLFlBQUo7QUFBaUJ6QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUN3QyxVQUFRdkMsQ0FBUixFQUFVO0FBQUNzQyxtQkFBYXRDLENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFFdkY7QUFFQXdDLFFBQVEsSUFBSXZDLE9BQU93QyxVQUFYLENBQXNCLE9BQXRCLENBQVI7QUFDQUQsTUFBTUUsS0FBTixDQUFZO0FBQ1hDLFVBQVEsVUFBVW5DLE1BQVYsRUFBa0JvQyxHQUFsQixFQUF1QjtBQUM5QjtBQUNBLFdBQU8sQ0FBQyxDQUFDcEMsTUFBVDtBQUNBLEdBSlU7QUFLWHFDLFVBQVEsWUFBWTtBQUNuQixXQUFPLElBQVA7QUFDQSxHQVBVO0FBUVhDLFVBQVEsWUFBWTtBQUNuQixXQUFPLElBQVA7QUFDQTtBQVZVLENBQVo7QUFZQUMsYUFBYSxJQUFJVCxZQUFKLENBQWlCO0FBQzdCM0IsUUFBTTtBQUNMcUMsVUFBTUM7QUFERCxHQUR1QjtBQUk3QkMsVUFBUTtBQUNQRixVQUFNQztBQURDO0FBSnFCLENBQWpCLENBQWI7QUFTQUUsYUFBYSxJQUFJYixZQUFKLENBQWlCO0FBQzdCYyxTQUFPO0FBQ05KLFVBQU1DLE1BREE7QUFFTkksV0FBTyxPQUZEO0FBR05DLFNBQUssR0FIQztBQUlOQyxjQUFVO0FBSkosR0FEc0I7QUFPN0JDLGNBQVk7QUFDWFIsVUFBTVM7QUFESyxHQVBpQjtBQVU3QkMsZUFBYUMsS0FWZ0I7QUFXN0IsbUJBQWlCWixVQVhZO0FBWTdCYSxVQUFRO0FBQ1BaLFVBQU1DLE1BREM7QUFFUEksV0FBTyxRQUZBO0FBR1BRLGVBQVcsWUFBVztBQUNyQixhQUFPLEtBQUtyRCxNQUFaO0FBQ0E7QUFMTSxHQVpxQjtBQW1CN0JzRCxVQUFRO0FBQ1BkLFVBQU1lLE1BREM7QUFFUFYsV0FBTyxrQkFGQTtBQUdQVyxTQUFLO0FBSEUsR0FuQnFCO0FBd0I3QkMsa0JBQWdCO0FBQ2ZqQixVQUFNa0IsSUFEUztBQUVmYixXQUFPLHFDQUZRO0FBR2ZjLGNBQVU7QUFISyxHQXhCYTtBQTZCN0JDLFdBQVM7QUFDUnBCLFVBQU1DLE1BREU7QUFFUkksV0FBTyxlQUZDO0FBR1JjLGNBQVUsSUFIRjtBQUlSYixTQUFLO0FBSkc7QUE3Qm9CLENBQWpCLENBQWI7QUFvQ0FyRCxPQUFPb0UsT0FBUCxDQUFlO0FBQ2RDLGtCQUFnQixVQUFTakMsRUFBVCxFQUFha0MsWUFBYixFQUEwQjtBQUN6Qy9CLFVBQU1LLE1BQU4sQ0FBYTtBQUFDMkIsV0FBTW5DO0FBQVAsS0FBYixFQUF5QjtBQUN4Qm9DLFlBQU07QUFDTGpCLG9CQUFZO0FBRFA7QUFEa0IsS0FBekI7QUFLQXJDLFlBQVFDLEdBQVIsQ0FBWSxRQUFaO0FBQ0E7QUFSYSxDQUFmO0FBV0FvQixNQUFNa0MsWUFBTixDQUFtQnZCLFVBQW5CLEUsQ0FDQSw4Qjs7Ozs7Ozs7Ozs7QUMxRUEsSUFBSXZELEtBQUo7QUFBVUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSCxRQUFNSSxDQUFOLEVBQVE7QUFBQ0osWUFBTUksQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJc0MsWUFBSjtBQUFpQnpDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ3dDLFVBQVF2QyxDQUFSLEVBQVU7QUFBQ3NDLG1CQUFhdEMsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUV2RnNDLGFBQWFxQyxhQUFiLENBQTJCLENBQUMsVUFBRCxDQUEzQjtBQUVBQyxVQUFVLElBQUkzRSxPQUFPd0MsVUFBWCxDQUFzQixVQUF0QixDQUFWO0FBQ0FtQyxRQUFRbEMsS0FBUixDQUFjO0FBQ2JDLFVBQVEsWUFBWTtBQUNuQixXQUFPLElBQVA7QUFDQSxHQUhZO0FBSWJFLFVBQVEsWUFBWTtBQUNuQixXQUFPLElBQVA7QUFDQSxHQU5ZO0FBT2JDLFVBQVEsWUFBWTtBQUNuQixXQUFPLElBQVA7QUFDQTtBQVRZLENBQWQ7QUFjQStCLFVBQVUsSUFBSTVFLE9BQU93QyxVQUFYLENBQXNCLFNBQXRCLENBQVY7QUFDQW9DLFFBQVFuQyxLQUFSLENBQWM7QUFDYkMsVUFBUSxVQUFVbkMsTUFBVixFQUFrQm9DLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sQ0FBQyxDQUFDcEMsTUFBVDtBQUNBLEdBSFk7QUFJYnFDLFVBQVEsWUFBWTtBQUNuQixXQUFPLElBQVA7QUFDQSxHQU5ZO0FBT2JDLFVBQVEsWUFBWTtBQUNuQixXQUFPLElBQVA7QUFDQTtBQVRZLENBQWQ7QUFhQWdDLGVBQWUsSUFBSXhDLFlBQUosQ0FBaUI7QUFDL0IzQixRQUFLO0FBQ0pxQyxVQUFNQyxNQURGO0FBRUpJLFdBQU87QUFGSCxHQUQwQjtBQUsvQjBCLFFBQU07QUFDTC9CLFVBQU1DLE1BREQ7QUFFTEksV0FBTztBQUZGLEdBTHlCO0FBUy9CTyxVQUFRO0FBQ1BaLFVBQU1DLE1BREM7QUFFUEksV0FBTyxRQUZBO0FBR1BRLGVBQVcsWUFBVztBQUNyQixhQUFPLEtBQUtyRCxNQUFaO0FBQ0E7QUFMTSxHQVR1QjtBQWdCL0J3RSxhQUFXO0FBQ1ZoQyxVQUFNa0IsSUFESTtBQUVWYixXQUFPLFlBRkc7QUFHVlEsZUFBVyxZQUFVO0FBQ3BCLGFBQU8sSUFBSUssSUFBSixFQUFQO0FBQ0E7QUFMUztBQWhCb0IsQ0FBakIsQ0FBZjtBQTBCQVcsUUFBUUgsWUFBUixDQUFzQkksWUFBdEIsRTs7Ozs7Ozs7Ozs7QUMzREEsSUFBSTdFLE1BQUo7QUFBV0osT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRSxTQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFHWCxJQUFJQyxPQUFPZ0YsUUFBWCxFQUFxQjtBQUNwQjtBQUVBaEYsU0FBT2lGLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFlBQVU7QUFDbkMvRCxZQUFRQyxHQUFSLENBQVksV0FBWjtBQUNBLFdBQU95RCxRQUFRTSxJQUFSLENBQWE7QUFBQ3ZCLGNBQVEsS0FBS3BEO0FBQWQsS0FBYixDQUFQO0FBQ0EsR0FIRDtBQUlBUCxTQUFPaUYsT0FBUCxDQUFlLE9BQWYsRUFBd0IsWUFBVTtBQUNqQy9ELFlBQVFDLEdBQVIsQ0FBWSxXQUFaO0FBQ0EsV0FBT29CLE1BQU0yQyxJQUFOLENBQVcsRUFBWCxDQUFQO0FBQ0EsR0FIRDtBQUlBbEYsU0FBT2lGLE9BQVAsQ0FBZSxhQUFmLEVBQThCLFVBQVM3QyxFQUFULEVBQVk7QUFDekNsQixZQUFRQyxHQUFSLENBQVksV0FBWjtBQUNBZ0UsVUFBTS9DLEVBQU4sRUFBVVksTUFBVjtBQUNBLFdBQU9ULE1BQU0yQyxJQUFOLENBQVc7QUFBQyxhQUFNOUM7QUFBUCxLQUFYLENBQVA7QUFDQSxHQUpEO0FBS0EsQ0FoQkQsTUFnQks7QUFDSmxCLFVBQVFDLEdBQVIsQ0FBWSxZQUFaO0FBQ0EsQzs7Ozs7Ozs7Ozs7QUNyQkQsSUFBSW5CLE1BQUo7QUFBV0osT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRSxTQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJcUYsa0JBQUo7QUFBdUJ4RixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNzRixxQkFBbUJyRixDQUFuQixFQUFxQjtBQUFDcUYseUJBQW1CckYsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQXRDLEVBQW9GLENBQXBGO0FBQXVGLElBQUlzRixvQkFBSjtBQUF5QnpGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ3VGLHVCQUFxQnRGLENBQXJCLEVBQXVCO0FBQUNzRiwyQkFBcUJ0RixDQUFyQjtBQUF1Qjs7QUFBaEQsQ0FBdEMsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVCLFFBQUosRUFBYUMsU0FBYjtBQUF1QjNCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiLEVBQTRDO0FBQUN3QixXQUFTdkIsQ0FBVCxFQUFXO0FBQUN1QixlQUFTdkIsQ0FBVDtBQUFXLEdBQXhCOztBQUF5QndCLFlBQVV4QixDQUFWLEVBQVk7QUFBQ3dCLGdCQUFVeEIsQ0FBVjtBQUFZOztBQUFsRCxDQUE1QyxFQUFnRyxDQUFoRztBQU1uVSxNQUFNdUYsU0FBU0QscUJBQXFCO0FBQ2xDL0QsVUFEa0M7QUFFbENDO0FBRmtDLENBQXJCLENBQWY7QUFLQTZELG1CQUFtQjtBQUNqQkU7QUFEaUIsQ0FBbkI7QUFHQXRGLE9BQU91RixPQUFQLENBQWUsTUFBTTtBQUVwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQUl2RixPQUFPZ0YsUUFBWCxFQUFxQixDQW9CcEI7QUFuQkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQkQ7O0FBQ0EsQ0EvQkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcbmlmKE1ldGVvci5pc0NsaWVudCl7XHJcblxyXG5cdFxyXG59XHJcbkZsb3dSb3V0ZXIudHJpZ2dlcnMuZW50ZXIoW2Z1bmN0aW9uKGNvbnRleHQsIHJlZGlyZWN0KXtcclxuXHRpZighTWV0ZW9yLnVzZXJJZCgpKXtcclxuXHRcdEZsb3dSb3V0ZXIuZ28oJy8nKTtcclxuXHR9XHJcbn1dKTtcclxuRmxvd1JvdXRlci5yb3V0ZSgnLycsIHtcclxuXHRuYW1lOiBcImhvbWVcIixcclxuXHRhY3Rpb24oKSB7XHJcblx0XHRCbGF6ZUxheW91dC5yZW5kZXIoJ0hvbWVMYXlvdXQnLCB7Y29udGVudDogJ0NvbnRlbnQnfSk7XHJcblx0fVxyXG59KTtcclxuRmxvd1JvdXRlci5yb3V0ZSgnL3JlY2lwZS1ib29rJywge1xyXG5cdG5hbWU6IFwicmVjaXBlLWJvb2tcIixcclxuXHRhY3Rpb24oKSB7XHJcblx0XHRCbGF6ZUxheW91dC5yZW5kZXIoJ01haW5MYXlvdXQnLCB7bWFpbjogJ0NvbnRlbnQnfSk7XHJcblx0fVxyXG59KTtcclxuRmxvd1JvdXRlci5yb3V0ZSgnL2Jvb2snLCB7XHJcblx0bmFtZTogXCJib29rXCIsXHJcblx0YWN0aW9uKCkge1xyXG5cdFx0QmxhemVMYXlvdXQucmVuZGVyKCdIb21lTGF5b3V0Jywge2NvbnRlbnQ6ICdpbnNlcnRCb29rRm9ybSd9KTtcclxuXHR9XHJcbn0pO1xyXG5cclxuRmxvd1JvdXRlci5yb3V0ZSgnL2Jvb2svOmlkJywge1xyXG5cdG5hbWU6IFwiYm9va1wiLFxyXG5cdGFjdGlvbihwYXJhbXMsIHF1ZXJ5UGFyYW1zKSB7XHJcblx0XHRCbGF6ZUxheW91dC5yZW5kZXIoJ0hvbWVMYXlvdXQnLCB7Y29udGVudDogJ0Jvb2tEZXRhaWwnLH0pO1xyXG5cdH1cclxufSk7XHJcblxyXG5GbG93Um91dGVyLnJvdXRlKCcvYmxvZy86cG9zdElkJywge1xyXG5cdGFjdGlvbjogZnVuY3Rpb24ocGFyYW1zLCBxdWVyeVBhcmFtcykge1xyXG5cdFx0Y29uc29sZS5sb2coXCJZZWFoISBXZSBhcmUgb24gdGhlIHBvc3Q6XCIsIHBhcmFtcy5wb3N0SWQpO1xyXG5cdH1cclxufSk7IiwiaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSc7XG5cbmNvbnN0IGxhcHRvcHMgPSBbXG4gIHsgbmFtZTogXCJNYWNCb29rUHJvXCIscmFtOiBcIjE2R0JcIixjcHU6IFwiaTcgNzcwMEhRXCIscHJpY2U6OTAwMDAwMH0sXG4gIHtuYW1lOiBcIkxlbm92b1wiLHJhbTogXCIxNkdCXCIsY3B1OiBcImk1IDcyMDBVXCIscHJpY2U6ODAwMDAwMCB9LFxuICB7bmFtZTogXCJIUFwiLHJhbTogXCIzMkdCXCIsY3B1OiBcImk3IDc3MDBIUVwiLHByaWNlOjUwMDAwMDB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IHR5cGVEZWZzID0gW1xuYFxuIFxudHlwZSBMYXB0b3AgeyBuYW1lOiBTdHJpbmcsIGNwdTogU3RyaW5nLCByYW06IFN0cmluZywgcHJpY2U6IEZsb2F0LH1cblxudHlwZSBFbWFpbCB7XG4gIGFkZHJlc3M6IFN0cmluZ1xuICB2ZXJpZmllZDogQm9vbGVhblxufVxuXG50eXBlIFVzZXIge1xuICBlbWFpbHM6IFtFbWFpbF1cbiAgcmFuZG9tU3RyaW5nOiBTdHJpbmdcbiAgX2lkOiBTdHJpbmdcbn1cblxudHlwZSBRdWVyeSB7XG4gIHVzZXI6IFVzZXIsXG4gIGxhcHRvcHM6IFtMYXB0b3BdXG59XG5gLFxuXTtcblxuZXhwb3J0IGNvbnN0IHJlc29sdmVycyA9IHtcblx0UXVlcnk6IHtcblx0XHR1c2VyKHJvb3QsIGFyZ3MsIGNvbnRleHQpIHtcblx0XHQgIC8qXG5cdFx0ICAgKiBXZSBhY2Nlc3MgdG8gdGhlIGN1cnJlbnQgdXNlciBoZXJlIHRoYW5rcyB0byB0aGUgY29udGV4dC4gVGhlIGN1cnJlbnRcblx0XHQgICAqIHVzZXIgaXMgYWRkZWQgdG8gdGhlIGNvbnRleHQgdGhhbmtzIHRvIHRoZSBgbWV0ZW9yL2Fwb2xsb2AgcGFja2FnZS5cblx0XHQgICAqL1xuXHRcdCAgcmV0dXJuIGNvbnRleHQudXNlcjtcblx0XHR9LFxuXHRcdGxhcHRvcHM6ICgpID0+IGxhcHRvcHNcblx0fSxcblx0VXNlcjoge1xuXHRcdGVtYWlsczogKHsgZW1haWxzIH0pID0+IGVtYWlscyxcblx0XHRyYW5kb21TdHJpbmc6ICgpID0+IFJhbmRvbS5pZCgpLFxuXHR9LFxufTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xyXG4vL1NpbXBsZVNjaGVtYS5leHRlbmRPcHRpb25zKFsnYXV0b2Zvcm0nXSk7XHJcblxyXG5Cb29rcyA9IG5ldyBNZXRlb3IuQ29sbGVjdGlvbihcImJvb2tzXCIpO1xyXG5Cb29rcy5hbGxvdyh7XHJcblx0aW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcclxuXHRcdC8vIHdyaXRlIHNvbWUgbG9naWMgdG8gYWxsb3cgdGhlIGluc2VydCBcclxuXHRcdHJldHVybiAhIXVzZXJJZDtcclxuXHR9LFxyXG5cdHVwZGF0ZTogZnVuY3Rpb24gKCkge1xyXG5cdFx0cmV0dXJuIHRydWU7XHJcblx0fSxcclxuXHRyZW1vdmU6IGZ1bmN0aW9uICgpIHtcclxuXHRcdHJldHVybiB0cnVlO1xyXG5cdH1cclxufSk7XHJcbkluZ3JlZGllbnQgPSBuZXcgU2ltcGxlU2NoZW1hKHtcclxuXHRuYW1lOiB7XHJcblx0XHR0eXBlOiBTdHJpbmdcclxuXHR9LFxyXG5cdGFtb3VueToge1xyXG5cdFx0dHlwZTogU3RyaW5nXHJcblx0fVxyXG5cdFxyXG59KTtcclxuQm9va1NjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xyXG5cdHRpdGxlOiB7XHJcblx0XHR0eXBlOiBTdHJpbmcsXHJcblx0XHRsYWJlbDogXCJUaXRsZVwiLFxyXG5cdFx0bWF4OiAyMDAsXHJcblx0XHRyZXF1aXJlZDogdHJ1ZVxyXG5cdH0sXHJcblx0cmVnaXN0ZXJlZDoge1xyXG5cdFx0dHlwZTogQm9vbGVhblxyXG5cdH0sXHJcblx0aW5ncmVkaWVudHM6IEFycmF5LFxyXG5cdFwiaW5ncmVkaWVudHMuJFwiOiBJbmdyZWRpZW50LFxyXG5cdGF1dGhvcjoge1xyXG5cdFx0dHlwZTogU3RyaW5nLFxyXG5cdFx0bGFiZWw6IFwiQXV0aG9yXCIsXHJcblx0XHRhdXRvVmFsdWU6IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRyZXR1cm4gdGhpcy51c2VySWRcclxuXHRcdH1cclxuXHR9LFxyXG5cdGNvcGllczoge1xyXG5cdFx0dHlwZTogTnVtYmVyLFxyXG5cdFx0bGFiZWw6IFwiTnVtYmVyIG9mIGNvcGllc1wiLFxyXG5cdFx0bWluOiAwXHJcblx0fSxcclxuXHRsYXN0Q2hlY2tlZE91dDoge1xyXG5cdFx0dHlwZTogRGF0ZSxcclxuXHRcdGxhYmVsOiBcIkxhc3QgZGF0ZSB0aGlzIGJvb2sgd2FzIGNoZWNrZWQgb3V0XCIsXHJcblx0XHRvcHRpb25hbDogdHJ1ZVxyXG5cdH0sXHJcblx0c3VtbWFyeToge1xyXG5cdFx0dHlwZTogU3RyaW5nLFxyXG5cdFx0bGFiZWw6IFwiQnJpZWYgc3VtbWFyeVwiLFxyXG5cdFx0b3B0aW9uYWw6IHRydWUsXHJcblx0XHRtYXg6IDEwMDBcclxuXHR9XHJcbn0pO1xyXG5NZXRlb3IubWV0aG9kcyh7XHJcblx0dG9nZ2xlTWVudUl0ZW06IGZ1bmN0aW9uKGlkLCBjdXJyZW50U3RhdGUpe1xyXG5cdFx0Qm9va3MudXBkYXRlKHtfaWQgOiBpZH0sIHtcclxuXHRcdFx0JHNldDoge1xyXG5cdFx0XHRcdHJlZ2lzdGVyZWQ6IHRydWVcclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0XHRjb25zb2xlLmxvZygndXBkYXRlJyk7XHJcblx0fVxyXG59KTtcclxuXHJcbkJvb2tzLmF0dGFjaFNjaGVtYShCb29rU2NoZW1hKTtcclxuLy9Cb29rcy5zY2hlbWEudmFsaWRhdGUobGlzdCk7IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XHJcblNpbXBsZVNjaGVtYS5leHRlbmRPcHRpb25zKFsnYXV0b2Zvcm0nXSk7XHJcblxyXG5saW5lVmFyID0gbmV3IE1ldGVvci5Db2xsZWN0aW9uKFwibGluZW52ZDNcIik7XHJcbmxpbmVWYXIuYWxsb3coe1xyXG5cdGluc2VydDogZnVuY3Rpb24gKCkge1xyXG5cdFx0cmV0dXJuIHRydWU7XHJcblx0fSxcclxuXHR1cGRhdGU6IGZ1bmN0aW9uICgpIHtcclxuXHRcdHJldHVybiB0cnVlO1xyXG5cdH0sXHJcblx0cmVtb3ZlOiBmdW5jdGlvbiAoKSB7XHJcblx0XHRyZXR1cm4gdHJ1ZTtcclxuXHR9XHJcbn0pO1xyXG5cclxuXHJcblxyXG5SZWNpcGVzID0gbmV3IE1ldGVvci5Db2xsZWN0aW9uKCdyZWNpcGVzJyk7XHJcblJlY2lwZXMuYWxsb3coe1xyXG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XHJcblx0XHRyZXR1cm4gISF1c2VySWQ7XHJcblx0fSxcclxuXHR1cGRhdGU6IGZ1bmN0aW9uICgpIHtcclxuXHRcdHJldHVybiB0cnVlO1xyXG5cdH0sXHJcblx0cmVtb3ZlOiBmdW5jdGlvbiAoKSB7XHJcblx0XHRyZXR1cm4gdHJ1ZTtcclxuXHR9XHJcbn0pO1xyXG5cclxuXHJcblJlY2lwZVNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xyXG5cdG5hbWU6e1xyXG5cdFx0dHlwZTogU3RyaW5nLFxyXG5cdFx0bGFiZWw6IFwiTmFtZVwiXHJcblx0fSxcclxuXHRkZXNjOiB7XHJcblx0XHR0eXBlOiBTdHJpbmcsXHJcblx0XHRsYWJlbDogXCJEZXNjcmlwdGlvblwiXHJcblx0fSxcclxuXHRhdXRob3I6IHtcclxuXHRcdHR5cGU6IFN0cmluZyxcclxuXHRcdGxhYmVsOiBcIkF1dGhvclwiLFxyXG5cdFx0YXV0b1ZhbHVlOiBmdW5jdGlvbigpIHtcclxuXHRcdFx0cmV0dXJuIHRoaXMudXNlcklkXHJcblx0XHR9XHJcblx0fSxcclxuXHRjcmVhdGVkQXQ6IHtcclxuXHRcdHR5cGU6IERhdGUsXHJcblx0XHRsYWJlbDogXCJDcmVhdGVkIEF0XCIsXHJcblx0XHRhdXRvVmFsdWU6IGZ1bmN0aW9uKCl7XHJcblx0XHRcdHJldHVybiBuZXcgRGF0ZSgpXHJcblx0XHR9XHJcblx0fVxyXG5cdFxyXG59KTtcclxuXHJcblJlY2lwZXMuYXR0YWNoU2NoZW1hKCBSZWNpcGVTY2hlbWEgKTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdC8vIFRoaXMgY29kZSBvbmx5IHJ1bnMgb24gdGhlIHNlcnZlclxuXHRcblx0TWV0ZW9yLnB1Ymxpc2goJ3JlY2lwZXMnLCBmdW5jdGlvbigpe1xuXHRcdGNvbnNvbGUubG9nKCdQdWJsaXNoZWQnKVxuXHRcdHJldHVybiBSZWNpcGVzLmZpbmQoe2F1dGhvcjogdGhpcy51c2VySWR9KTtcblx0fSk7XG5cdE1ldGVvci5wdWJsaXNoKCdib29rcycsIGZ1bmN0aW9uKCl7XG5cdFx0Y29uc29sZS5sb2coJ1B1Ymxpc2hlZCcpXG5cdFx0cmV0dXJuIEJvb2tzLmZpbmQoe30pO1xuXHR9KTtcblx0TWV0ZW9yLnB1Ymxpc2goJ3NpbmdsZWJvb2tzJywgZnVuY3Rpb24oaWQpe1xuXHRcdGNvbnNvbGUubG9nKCdQdWJsaXNoZWQnKTtcblx0XHRjaGVjayhpZCwgU3RyaW5nKTtcblx0XHRyZXR1cm4gQm9va3MuZmluZCh7J19pZCc6aWR9KTtcblx0fSk7XG59ZWxzZXtcblx0Y29uc29sZS5sb2coXCJOb3Qgc2VydmVyXCIpO1xufSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY3JlYXRlQXBvbGxvU2VydmVyIH0gZnJvbSAnbWV0ZW9yL2Fwb2xsbyc7XG5pbXBvcnQgeyBtYWtlRXhlY3V0YWJsZVNjaGVtYSB9IGZyb20gJ2dyYXBocWwtdG9vbHMnO1xuXG5pbXBvcnQgeyB0eXBlRGVmcywgcmVzb2x2ZXJzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3NjaGVtYSc7XG5cbmNvbnN0IHNjaGVtYSA9IG1ha2VFeGVjdXRhYmxlU2NoZW1hKHtcbiAgdHlwZURlZnMsXG4gIHJlc29sdmVycyxcbn0pO1xuXG5jcmVhdGVBcG9sbG9TZXJ2ZXIoe1xuICBzY2hlbWEsXG59KTtcbk1ldGVvci5zdGFydHVwKCgpID0+IHsgIFxuXHRcblx0Ly9Ub2Rvcy5pbnNlcnQoe19pZDogJ215LXRvZG8nfSk7XG5cdC8vLy8gU28gdGhpcyBsaW5lIHdpbGwgcmV0dXJuIHNvbWV0aGluZ1xuXHQvL2NvbnN0IHRvZG8gPSBUb2Rvcy5maW5kT25lKHtfaWQ6ICdteS10b2RvJ30pO1xuXHQvLyBMb29rIG1hLCBubyBjYWxsYmFja3MhXG5cdC8vY29uc29sZS5sb2codG9kbyk7XG5cdC8vUmVjaXBlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdyZWNpcGVzJyk7XG5cdC8vQm9va3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcImJvb2tzXCIpO1xuXHRpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdFx0LypNZXRlb3IucHVibGlzaChcImJvb2tzXCIsIGZ1bmN0aW9uICgpIHtcblx0XHQvL2NvbnNvbGUubG9nKEJvb2tzLmZpbmQoKSk7XG5cdFx0XHRyZXR1cm4gQm9va3MuZmluZCgpO1xuXHRcdH0pO1xuXHRcdE1ldGVvci5wdWJsaXNoKCdzaW5nbGVib29rcycsIGZ1bmN0aW9uKGlkKXtcblx0XHRcdGNvbnNvbGUubG9nKCdQdWJsaXNoZWQnKTtcblx0XHRcdGNoZWNrKGlkLCBTdHJpbmcpO1xuXHRcdFx0cmV0dXJuIEJvb2tzLmZpbmQoeydfaWQnOmlkfSk7XG5cdFx0fSk7XG5cdFx0TWV0ZW9yLm1ldGhvZHMoe1xuXHRcdFx0dG9nZ2xlTWVudUl0ZW06IGZ1bmN0aW9uKGlkLCBjdXJyZW50U3RhdGUpe1xuXHRcdFx0XHRCb29rcy51cGRhdGUoe19pZCA6IGlkfSwge1xuXHRcdFx0XHRcdCRzZXQ6IHtcblx0XHRcdFx0XHRcdHJlZ2lzdGVyZWQ6IGZhbHNlXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KTtcblx0XHRcdFx0Y29uc29sZS5sb2coJ3VwZGF0ZScpO1xuXHRcdFx0fVxuXHRcdH0pOyovXG5cdH1cblx0Ly9zZXR1cEFwaSgpOyAvLyBpbnN0YW50aWF0ZSBvdXIgbmV3IEV4cHJlc3MgYXBwXG59KTtcblxuIl19
